import * as component from "./components/index"
import { Attribute } from "./components/pixelArt/pixelArt";
import { objectWithImages } from "./data/data"

class appContainer extends HTMLElement {

    blNwh: any = [];

    constructor(){
        super();
        this.attachShadow({mode: "open"});

        objectWithImages.forEach((bigCanvas) => {
            const bigBox = this.ownerDocument.createElement("div");
            bigBox.classList.add("bigBox");
            bigCanvas.forEach((medCanvas) => {
                const medBox = this.ownerDocument.createElement("div");
                medBox.classList.add("medBox");
                medCanvas.forEach((LilCanvas) => {
                    const LilBox = this.ownerDocument.createElement("pixelArt");
                    if (LilCanvas === 0) {
                        LilBox.setAttribute(Attribute.color, "white")
                    } else {
                        LilBox.setAttribute(Attribute.color, "black")
                    };
                    medBox.appendChild(LilBox);
                })
                bigBox.appendChild(medBox)
            })
            this.blNwh.push(bigBox);
        });
    }

    connectedCallback(){
        this.render();
    }

    render(){
        if(this.shadowRoot){
            this.shadowRoot.innerHTML = `<link rel="stylesheet" href="./pixel.css">`
            this.blNwh.forEach((div:HTMLDivElement) => {
                this.shadowRoot?.appendChild(div)
            });
            }
        }
    }


customElements.define("app-container", appContainer);